package sample;

import sample.model.User;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;

import java.sql.PreparedStatement;


public class DBcon {
    private static final String DB_URL = "jdbc:sqlite:con.db";
    private static final String DB_Query = "Select * from users where username = ? and password = ?";

    private static final String DB_InsertedQuery = "Insert into users (firstname, lastname, username, password) values (?,?,?,?)";


    public boolean validate(String username, String password) throws SQLException {

        // Step 1: Establishing a Connection and
        // try-with-resource statement will auto close the connection.
        try (Connection connection = DriverManager
                .getConnection(DB_URL);

             // Step 2:Create a statement using connection object
             PreparedStatement preparedStatement = connection.prepareStatement(DB_Query)) {
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            System.out.println(preparedStatement);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return true;
            }


        } catch (SQLException e) {
            // print SQL exception information
            e.printStackTrace();
        }
        return false;
    }
    public User createUser(String firstname, String lastname, String username, String password){
        // Step 1: Establishing a Connection and
        // try-with-resource statement will auto close the connection.
        User newUser = null;
        try (Connection connection = DriverManager
                .getConnection(DB_URL);


             // Step 2:Create a statement using connection object
             PreparedStatement preparedStatement = connection.prepareStatement(DB_InsertedQuery)) {
            preparedStatement.setString(1, firstname);
            preparedStatement.setString(2, lastname);
            preparedStatement.setString(3, username);
            preparedStatement.setString(4, password);
            preparedStatement.executeUpdate();
            newUser = new User(firstname,lastname,username,password);
            System.out.println(preparedStatement);
//
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()) {
//                return true;
//            }

        } catch (SQLException e) {
            // print SQL exception information
            e.printStackTrace();
        }
        return newUser;
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:con.db");
    }


}
