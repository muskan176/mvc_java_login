package sample.controller;

import java.io.IOException;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.Window;
import sample.DBcon;


public class LoginController {
    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button loginButton;

    @FXML
    private Button signupButton;

    private Stage stage;
   

    public LoginController(Stage stage) {
        this.stage = stage;
    }


    public void login(ActionEvent event) throws SQLException{
        Window loginWindow = loginButton.getScene().getWindow();
        String username = usernameField.getText();
        String password = passwordField.getText();

        if(usernameField.getText().isEmpty()){
        showAlert(Alert.AlertType.ERROR, loginWindow, "Form Error!",
                "Please enter your username");
        return;
    }
        if (passwordField.getText().isEmpty()) {
        showAlert(Alert.AlertType.ERROR,loginWindow, "Form Error!",
                "Please enter a password");
        return;
    }
        DBcon db = new DBcon();
        Boolean flag = db.validate(username,password);

        if(!flag){
            infoBox("Please enter correct username and password",null,"failed");
        }
        else{
            infoBox("Login Successful!"," ","Congratulations!");
        }


    }

    private void infoBox(String infoMessage,String title,String headerText) {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setContentText(infoMessage);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.showAndWait();
    }

    private void showAlert(AlertType error, Window loginWindow, String s, String please_enter_a_password) {
        Alert alert = new Alert(error);
        alert.setTitle(s);
        alert.setHeaderText(null);
        alert.setContentText(please_enter_a_password);
        alert.initOwner(loginWindow);
        alert.show();
    }

    public void signup(ActionEvent event) throws SQLException {

        try {
            FXMLLoader loader = new FXMLLoader(this.getClass().getResource("/view/signUp.fxml"));

            // Customize controller instance
            SignUpController signupController = new SignUpController(this.stage);
            loader.setController(signupController);
            VBox root = (VBox)loader.load();
            signupController.showStage(root);
            //this.stage.close();

        } catch (IOException var5) {
            var5.printStackTrace();
        }
//
//        Parent root = null;
//        try {
//            root = FXMLLoader.load(getClass().getResource("signUp.fxml"));
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//        stage.setTitle("SignUp");
//        stage.setScene(new Scene(root, 800, 500));
//        stage.show();

    }
    public void showStage(Pane root){
        Scene scene = new Scene(root, 700.0, 300.0);
        this.stage.setScene(scene);
        this.stage.setResizable(true);
        this.stage.setTitle("Login");
        this.stage.show();
    }
    @FXML
    public void initialize() {
        this.loginButton.setOnAction((event) -> {
            try {
                this.login(event);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        });
        this.signupButton.setOnAction((event) -> {
            try{
            this.signup(event);
            }
             catch(SQLException e) {
                throw new RuntimeException(e);
            }
        });

    }


    }



